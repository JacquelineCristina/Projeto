<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Style/style.css">
        <title>Incio</title>
    </head>
    <body>
        <section id="menu">
            <h2>MENU</h2>
            <ul>
                <li>Cliente
		    <ul><li><a  href="View/FrmCadastrarCliente.php" >Cadastrar Cliente</a><li>
			<li><a href="View/FrmConsultarCliente.php" >Consultar Cliente</a><li>
		    </ul>		
		</li>
                <li>Produto
		    <ul><li><a href="View/FrmCadastroProduto.php" >Cadastrar Produto</a><li>
		    <li><a href="View/FrmConsultarProduto.php" >Consultar Produto</a><li>
		    </ul>
		</li>
                <li>Pedidos
		    <ul>
                        <li><a href="View/FrmCadastrarPedido.php" >Novo Pedido</a><li>
	            <li><a href="#">Consultar Pedidos</a><li>
		    </ul>
		</li>
            </ul>
        </section>
        <section id="conteudo">
            
        </section>
    </body>
</html>
