<?php

$id = $_REQUEST['radioPedido'];
include_once '../Control/conectaBanco.php';
?>
<script type="text/javascript">
    decisao =confirm("Certeza que deseja excluir? ");
    if(desicao){
    </script>
        <?php
            $query = "DELETE FROM pedido WHERE pedido_id = '$id'";
            $executar = mysqli_query($conecta, $query)or die(mysqli_error());
            if($executar){
                ?>
            <script type="text/javascript">
                    alert("Pedido Excluido!");
                    top.location='../View/FrmConsultarPedido.php';
            </script>
                <?php
            }
            echo 'Erro';
        ?>
        
    <script>    
    }else{
        top.location='../View/FrmConsultarPedido.php';
    }
</script>

