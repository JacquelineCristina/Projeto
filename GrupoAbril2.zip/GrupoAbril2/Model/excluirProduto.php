<?php
$id = $_GET['id'];
include_once '../Control/conectaBanco.php';
?>
<script type="text/javascript">
    decisao =confirm("Certeza que deseja excluir? ");
    if(desicao){
    </script>
        <?php
            $query = "DELETE FROM produto WHERE prod_id = '$id'";
            $executar = mysqli_query($conecta, $query)or die(mysqli_error());
            if($executar){
                ?>
            <script type="text/javascript">
                    alert("Produto Excluido!");
                    top.location='../View/FrmConsultaProduto.php';
            </script>
                <?php
            }
            echo 'Erro';
        ?>
        
    <script>    
    }else{
        top.location='../View/FrmConsultaProduto.php';
    }
</script>


