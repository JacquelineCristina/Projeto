<?php
include_once '../Control/conectaBanco.php';

if(!isset($_POST["submit"])){
    
$produto_id = $_REQUEST['radioProduto'];
$cliente_id = $_REQUEST['radioCliente'];
 $query = "INSERT INTO pedido(produto_id, cliente_id) "
         . "VALUES ('$produto_id', '$cliente_id')"; 
 $executar = mysqli_query($conecta, $query) ;
 if($executar){
 ?><script>
        alert("Cadastrado");
        top.location='../View/FrmCadastrarPedido.php';
      </script><?php
}else{
    ?><script>
        alert("Produto já existe");
        top.location='../View/FrmCadastrarPedido.php';
      </script>

<?php
}
}
