<?php
include_once '../Control/conectaBanco.php';

//Salvar variáveis via metodo POST
if(!isset($_POST["submit"])){
$prod_nome = $_REQUEST['prod_nome'];
$prod_descricao = $_REQUEST['prod_descricao'];
$prod_preco = $_REQUEST['prod_preco'];

$query = "SELECT * from produto WHERE prod_nome = '$prod_nome'";
$executar = mysqli_query($conecta, $query);
$num = mysqli_num_rows($executar);
    
if($num==0){
   $query = "INSERT INTO produto(prod_nome, prod_descricao, prod_preco)"
            . "VALUES('$prod_nome', '$prod_descricao', '$prod_preco')";
    $executar = mysqli_query($conecta,$query) or die("Erro ao Realizar cadastro" + mysqli_error());  
     ?><script>
        alert("Cadastrado");
        top.location='../View/FrmCadastroProduto.php';
      </script><?php
}else{
    ?><script>
        alert("Produto já existe");
        top.location='../View/FrmCadastroProduto.php';
      </script>

<?php
}
    
}



