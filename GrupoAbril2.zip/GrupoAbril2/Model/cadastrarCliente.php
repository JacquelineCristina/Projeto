<?php

include_once '../Control/conectaBanco.php';

if(!isset($_POST["submit"])){
    $cli_nome = $_REQUEST['cli_nome'];
    $cli_email = $_REQUEST['cli_email'];
    $cli_telefone = $_REQUEST['cli_telefone'];
    
    $query = "INSERT INTO cliente(cli_nome, cli_email, cli_telefone)"
            . "VALUES ('$cli_nome', '$cli_email', '$cli_telefone')";
    $executar = mysqli_query($conecta, $query) or die(mysqli_error());
    if($executar){
    ?>
    <script>
        alert("Cliente cadastrado");
        top.location ='../View/FrmCadastrarCliente.php';
    </script>
    <?php    
    }
        
}else{
    ?>
    <script>
        alert("Dados não recebidos");
        top.location ='../View/FrmCadastrarCliente.php';
    </script>
    <?php
}


