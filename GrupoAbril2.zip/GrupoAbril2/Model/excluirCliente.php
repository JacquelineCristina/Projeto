
<?php
$id = $_GET['id'];
include_once '../Control/conectaBanco.php';
?>
<script type="text/javascript">
    decisao =confirm("Certeza que deseja excluir? ");
    if(desicao){
    </script>
        <?php
            $query = "DELETE FROM cliente WHERE cli_id = '$id'";
            $executar = mysqli_query($conecta, $query)or die(mysqli_error());
            if($executar){
                ?>
            <script type="text/javascript">
                    alert("Cliente Excluido!");
                    top.location='../View/FrmConsultarCliente.php';
            </script>
                <?php
            }
            echo 'Erro';
        ?>
        
    <script>    
    }else{
        top.location='../View/FrmConsultarCliente.php';
    }
</script>
