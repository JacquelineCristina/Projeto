<?php
include_once '../Control/conectaBanco.php';

$query = "SELECT produto_id, prod_nome, cli_nome, pedido_id from pedido
INNER JOIN produto on pedido.produto_id = produto.prod_id
INNER JOIN cliente ON pedido.cliente_id = cliente.cli_id";
$executar = mysqli_query($conecta, $query);
$num = mysqli_num_rows($executar);
if($num ==0 ){
   //echo 'Não existem produtos cadastrados';
}else{
    $i =0;
    while($array_sql = mysqli_fetch_array($executar)){
    $array_pedido[$i]['pedido_id'] = $array_sql['pedido_id'];
    $array_pedido[$i]['produto_id'] = $array_sql['produto_id'];
    $array_pedido[$i]['prod_nome'] = $array_sql['prod_nome'];
    $array_pedido[$i]['cli_nome'] = $array_sql['cli_nome'];
    
    $i++;
   
    
}

}

