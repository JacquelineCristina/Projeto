<?php

include_once '../Control/conectaBanco.php';

$query = "SELECT * from produto";
$executar = mysqli_query($conecta, $query);
$num = mysqli_num_rows($executar);
if($num ==0 ){
   //echo 'Não existem produtos cadastrados';
}else{
    $i =0;
    while($array_sql = mysqli_fetch_array($executar)){
    $array_produto[$i]['prod_id'] = $array_sql['prod_id'];
    $array_produto[$i]['prod_nome'] = $array_sql['prod_nome'];
    $array_produto[$i]['prod_descricao'] = $array_sql['prod_descricao'];
    $array_produto[$i]['prod_preco'] = $array_sql['prod_preco'];
    $i++;
}

}



