<?php

include_once '../Control/conectaBanco.php';

$query = "SELECT * FROM cliente";
$executar = mysqli_query($conecta, $query);
$numClientes = mysqli_num_rows($executar);
    if($numClientes ==0 ){
   echo "erro";
    
    }else{
        $i =0;
    while($array_sql = mysqli_fetch_array($executar)){
    $array_cliente[$i]['cli_id'] = $array_sql['cli_id'];
    $array_cliente[$i]['cli_nome'] = $array_sql['cli_nome'];
    $array_cliente[$i]['cli_email'] = $array_sql['cli_email'];
    $array_cliente[$i]['cli_telefone'] = $array_sql['cli_telefone'];
    $i++;
    }
    
}