<?php

$conecta =  mysqli_connect("localhost","user","password","estoque"); 
if(!$conecta){//Caso haja algum problema na conexão será informado
    echo 'Problemas ao conectar com o Banco';
}else{
    //echo"conectou com o banco";
}

