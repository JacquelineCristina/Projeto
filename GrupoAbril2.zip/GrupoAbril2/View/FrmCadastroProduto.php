<!DOCTYPE html>
<?php include './menu.php'; ?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../Style/style.css">
        <title>Pooduto</title>
    </head>
    <body>
         
        <section id="conteudo">
            <form method="POST" action="../Model/cadastrarProduto.php" name="cadProduto" id="cadProduto" >
                <table>
                    <tr><!--- nome, desc prec-->
                        <td>Nome: </td><td><input type="text" name="prod_nome"></td>
                    </tr>
                    <tr>
                        <td>Descrção: </td><td><input type="text" name="prod_descricao" id="prod_descricao"></td>
                    </tr>
                    <tr>
                        <td>Preço: </td><td><input type="text" name="prod_preco"></td>
                    </tr>
                    <tr> 
                        <td><input type="reset" value="Limpar"></td>
                        <td><input type="submit" value="Salvar" name="insert"></td>
                    </tr>
                </table>
            </form>
        </section>
    </body>
</html>
