<!DOCTYPE html>
<?php include_once './menu.php'; 
 include_once '../Control/buscarDadosPedido.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../Style/style.css">
        <title></title>
    </head>
    <body>
       <section id="conteudo">
           <form method="POST" action="../Model/excluirPedido.php">
            <?php 
		if($num==0){
		  echo "Não existem Pedidos cadastrados";	
		}else{
		   ?>
               <table border="1">
                 <tr><td>Código do Produto</td>
                 <td>Cliente</td>
                 <td>Produto</td>
                 <td>Excluir</td>
                
                </tr>
              <?php
		 foreach($array_pedido as $key => $pedido){
		   if(is_int($key)){
		    ?>
                       <tr>
			<td><?php echo $pedido['pedido_id'] ?></td>
			<td><?php echo $pedido['cli_nome'] ?> </td>
			<td><?php echo $pedido['prod_nome'] ?> </td>
                        <td><input type="radio" name="radioPedido" value="<?php echo $pedido['pedido_id'] ?>"></td>
		    
                       </tr>
                    <?php
                    }
		   

                 }

	 }

         ?><tr><td></td><td><input type="submit" value="Excluir"></td></tr>
               </table>
                    </form>
        </section>
    </body>
</html>
