<!DOCTYPE html>
<?php include_once '../Control/buscarDadosCliente.php';
 include './menu.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../Style/style.css">
        <title>Cliente</title>
    </head>
    <body>
        
        <section id="conteudo">
            <?php 
		if($numClientes==0){
		  echo "Não existem Clientes cadastrados";	
		}else{
		   ?>
               <table border="1">
                 <tr><td>Código</td>
                 <td>Nome</td>
                 <td>Email</td>
                 <td>Telefone</td>
                 <td>Excluir</td>
                
                </tr>
              <?php
		 foreach($array_cliente as $key => $cliente){
		   if(is_int($key)){
		    ?>
                       <tr>
			<td><?php echo $cliente['cli_id'] ?></td>
			<td><?php echo $cliente['cli_nome'] ?> </td>
			<td><?php echo $cliente['cli_email'] ?> </td>
			<td><?php echo $cliente['cli_telefone'] ?></td>
			<td><a href="../Model/excluirCliente.php?id=<?php echo $cliente['cli_id'] ?>"><img src="../imagens/excluir.png"></a></td>
		    </tr>
                    <?php
                    }
		   

                 }

	 }

	    ?>
        </section>
            
      
    </body>
</html>
