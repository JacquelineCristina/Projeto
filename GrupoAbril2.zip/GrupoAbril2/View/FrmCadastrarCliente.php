<!DOCTYPE html>
<?php include './menu.php'; ?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../Style/style.css">
        <title>Cliente</title>
    </head>
    <body>
        <section id="conteudo">
           <form method="POST" action="../Model/cadastrarCliente.php" name="cadCliente" id="cadCliente" >
                <table>
                    <tr><!--- nome, desc prec-->
                        <td>Nome: </td><td><input type="text" name="cli_nome"></td>
                    </tr>
                    <tr>
                        <td>Email: </td><td><input type="text" name="cli_email" id="cli_email"></td>
                    </tr>
                    <tr>
                        <td>Telefone: </td><td><input type="text" name="cli_telefone"></td>
                    </tr>
                    <tr> 
                        <td><input type="reset" value="Limpar"></td>
                        <td><input type="submit" value="Salvar" name="insert"></td>
                    </tr>
                </table>
            </form>
        </section>
    </body>
</html>
