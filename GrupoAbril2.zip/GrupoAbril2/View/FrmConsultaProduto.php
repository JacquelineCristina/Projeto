﻿<!DOCTYPE html>
<?php include_once '../Control/buscarDadosProduto.php';
 include_once './menu.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Produto</title>
        <link rel="stylesheet" href="../Style/style.css">
    </head>
    <body>
      
        <section id="conteudo">
           
            <?php
            if($num==0 ){
                echo"Não existem produtos cadastrados";
            }else{
                ?>
             <table border="1">
                <tr><td>Código</td>
                <td>Nome</td>
                <td>Descrição</td>
                <td>Preço</td>
                <td>Excluir</td>
                
                
                </tr>
            <?php
                foreach (@$array_produto as $key => $produto) {
                   // print_r($produto);
                    if(is_int($key)){
                        $id = $produto['prod_id'];
                     ?>
               
                        <tr>
                        
                            <td><label id="<?php echo $produto['prod_id'] ?>"><?php echo $produto['prod_id'] ?></label> </td>            
                            <td><input type="text" value="<?php echo $produto['prod_nome'] ?>" id="<?php echo $produto['prod_nome'] ?>"></td> 
                            <td><input type="text" value="<?php echo $produto['prod_descricao'] ?>" id="<?php echo $produto['prod_descricao'] ?>"></td> 
                            <td><input type="text" value="<?php echo $produto['prod_preco'] ?>" id="<?php echo $produto['prod_preco'] ?>"></td> 
                            <td><a href="../Model/excluirProduto.php?id=<?php echo $produto['prod_id'] ?>"><img src="../imagens/excluir.png"></a></td>
                            
                        
                        </tr>
                       
                    <?php
                    }
                    
                }
            }
                ?>
            
                
            </table>
        </section>
    </body>
</html>
