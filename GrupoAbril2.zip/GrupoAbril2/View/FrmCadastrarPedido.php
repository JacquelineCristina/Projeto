<!DOCTYPE html>
<?php 

include_once '../Control/buscarDadosProduto.php'; 
 include './menu.php';
 
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Pedido</title>
    </head>
    <body>
	
        <section id="conteudo">
            <form method="POST" action="../Model/cadastrarPedido.php " id="formPedido">  
            <?php
            if($num==0 ){
                echo"Não existem produtos cadastrados";
            }else{
                ?>
             <table border="1">
                <tr><td>Código</td>
                <td>Nome</td>
                <td>Descrição</td>
                <td>Preço</td>
                <td>Selecionar</td>
                
                </tr>
            <?php
                foreach (@$array_produto as $key => $produto) {
                   // print_r($produto);
                    if(is_int($key)){
                        $id = $produto['prod_id'];
                     ?>
               
                        <tr>
                        
                            <td><label id="<?php echo $produto['prod_id'] ?>"><?php echo $produto['prod_id'] ?></label> </td>            
                            <td><input type="text" value="<?php echo $produto['prod_nome'] ?>" id="<?php echo $produto['prod_nome'] ?>"></td> 
                            <td><input type="text" value="<?php echo $produto['prod_descricao'] ?>" id="<?php echo $produto['prod_descricao'] ?>"></td> 
                            <td><input type="text" value="<?php echo $produto['prod_preco'] ?>" id="<?php echo $produto['prod_preco'] ?>"></td> 
			    <td><input type="radio" id="radioProduto" name="radioProduto" value="<?php echo $produto['prod_id'] ?>"></td>
                            
                        
                        </tr>
                       
                    <?php
                    }
                    
                }
            }
            echo '<br >';
            include_once '../Control/buscarDadosCliente.php';
            
		if($numClientes==0){
		  echo "Não existem Clientes cadastrados";	
		}else{
		   ?>
                        
               <table border="1">
                   <tr ></tr>
                 <tr><td>Código</td>
                 <td>Nome</td>
                 <td>Email</td>
                 <td>Telefone</td>
                 <td>Selecionar</td>
                
                </tr>
              <?php
		 foreach($array_cliente as $key => $cliente){
		   if(is_int($key)){
		    ?>
                       <tr>
			<td><?php echo $cliente['cli_id'] ?></td>
			<td><?php echo $cliente['cli_nome'] ?> </td>
			<td><?php echo $cliente['cli_email'] ?> </td>
			<td><?php echo $cliente['cli_telefone'] ?></td>
			<td><input type="radio" id="radioCliente" name="radioCliente" value="<?php echo $cliente['cli_id'] ?>"></td>
                        </tr>
                    <?php
                    }
		   

                 }

	 }

	   
                ?>
            
                
            </table>
                        <input type="submit" value="Salvar Pedido">
                </form>
        </section>
        
            <table>
            </table>
        
    </body>
</html>
