<!DOCTYPE html>
<?php $id = $_GET['id'];
 session_start();
 $_SESSION['id'] = $id;
 
 include_once '../Control/buscarDadosProduto.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Produto</title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
